package com.nova.browser

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Color
import android.graphics.Typeface
import android.content.Intent
import android.net.Uri
import android.widget.*

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var status: TextView
    private val bg = Color.rgb(16, 20, 38)
    private val purple = Color.rgb(102, 87, 232)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 246, 252))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 12)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "Nova Browser"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "تصفّح وابحث بسهولة"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 3, 0, 12)
        }
        address = EditText(this).apply {
            hint = "ابحث أو اكتب عنوان الموقع"
            textSize = 15f
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(14, 8, 14, 8)
            setBackgroundColor(Color.WHITE)
            setSelectAllOnFocus(false)
        }
        address.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                navigate(address.text.toString()); true
            } else false
        }

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 0)
        }
        val back = button("رجوع") { if (web.canGoBack()) web.goBack() }
        val forward = button("التالي") { if (web.canGoForward()) web.goForward() }
        val home = button("الرئيسية") { loadHome() }
        val vpn = button("إعداد VPN") { showVpnInfo() }
        actions.addView(back, weightParams())
        actions.addView(forward, weightParams())
        actions.addView(home, weightParams())
        actions.addView(vpn, weightParams())

        header.addView(title)
        header.addView(subtitle)
        header.addView(address, LinearLayout.LayoutParams(-1, 48))
        header.addView(actions)
        root.addView(header)

        status = TextView(this).apply {
            text = "VPN: غير متصل"
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(12, 6, 12, 6)
            setBackgroundColor(Color.rgb(232, 232, 242))
        }
        root.addView(status)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    address.setText(url ?: "")
                    status.text = "VPN: غير متصل • تحميل الصفحة..."
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    address.setText(url ?: "")
                    status.text = "VPN: غير متصل • الصفحة جاهزة"
                }
            }
            webChromeClient = WebChromeClient()
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        loadHome()
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, 42, 1f).apply {
        setMargins(3, 0, 3, 0)
    }

    private fun button(label: String, click: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(purple)
            setOnClickListener { click() }
        }
    }

    private fun navigate(input: String) {
        val text = input.trim()
        if (text.isEmpty()) return
        val url = when {
            text.startsWith("https://") || text.startsWith("http://") -> text
            text.contains(".") && !text.contains(" ") -> "https://$text"
            else -> "https://www.google.com/search?q=" + Uri.encode(text)
        }
        web.loadUrl(url)
    }

    private fun loadHome() {
        address.setText("")
        web.loadDataWithBaseURL(
            "https://www.google.com",
            """<html><meta name="viewport" content="width=device-width, initial-scale=1">
            <body style="font-family:sans-serif;background:#f5f6fc;text-align:center;padding:40px 18px;color:#101426">
            <div style="font-size:42px;font-weight:bold;color:#6657e8">Nova</div>
            <h2>أهلاً بك في Nova Browser</h2>
            <p>اكتب كلمة البحث أو عنوان الموقع في الشريط بالأعلى.</p>
            <p style="color:#666;font-size:13px">متصفح تجريبي أولي</p>
            </body></html>""",
            "text/html", "UTF-8", null
        )
    }

    private fun showVpnInfo() {
        AlertDialog.Builder(this)
            .setTitle("اتصال VPN")
            .setMessage(
                "ميزة VPN الحقيقي تحتاج ملف إعدادات من مزوّد موثوق أو خادم مجاني فعلي. " +
                "هذا الإصدار لا يحتوي على خوادم VPN مدمجة ولا يغيّر عنوان IP بعد. " +
                "يمكنك تثبيت تطبيق WireGuard الرسمي واستيراد ملف إعدادات موثوق منه، ثم تصفح الإنترنت عبر اتصال VPN النظامي."
            )
            .setPositiveButton("فتح WireGuard") { _, _ ->
                val launch = packageManager.getLaunchIntentForPackage("com.wireguard.android")
                if (launch != null) startActivity(launch)
                else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.wireguard.android")))
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
