# Nova Browser (Android Studio project)

This is a starter Android app project for Nova Browser. It includes:
- Google search and website navigation in an Android WebView
- Back, forward, home, and VPN setup buttons
- Arabic UI

## VPN status
This starter project does **not** bundle VPN servers and does not change the IP by itself.
For real VPN use, install the official WireGuard app and import a configuration obtained from a trustworthy VPN provider. The app's VPN button opens WireGuard or its Play Store listing. Do not use random public VPN configuration files unless you trust the operator.

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync to finish.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be shown by Android Studio when the build finishes.

This project has not been compiled or device-tested in this environment.
